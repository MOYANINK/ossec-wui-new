<?php
require_once 'Ossec/Alert.php';
require_once 'Ossec/AlertList.php';
//TODO: This can probably be a method of AlertList
function __os_createresults($out_file, $alert_list)
{
    /* Opening output file */
    $fp = fopen($out_file, "w");
    if(!$fp) {
        return(NULL);
    }
    fwrite( $fp, $alert_list->toHTML() );
}
function __os_parsealert(&$fp, $curr_time, 
                         $init_time, $final_time, $min_level,
                         $rule_id, $location_pattern, 
                         $str_pattern, $group_pattern, $group_regex,
                         $srcip_pattern, $user_pattern, 
                         $log_pattern, $log_regex, $rc_code_hash)
{
    $evt_time = 0;
    $evt_id = 0;
    $evt_level = 0;
    $evt_description = NULL;
    $evt_location = NULL;
    $evt_srcip = NULL;
    $evt_user = NULL;
    $evt_group = NULL;
    $evt_msg[0] = "";
    
    while(!feof($fp)) 
    {
        $buffer = fgets($fp, 1024);
        
        /* Getting event header */
        if(strncmp($buffer, "** Alert", 8) != 0)
        {
            continue;
        }

        
        /* Getting event time */
        $evt_time = substr($buffer, 9, 10);
        if(is_numeric($evt_time) === FALSE)
        {
            $evt_time = 0;
            continue;
        }

        /* Checking if event time is in the timeframe */
        if(($init_time != 0) && ($evt_time < $init_time))
        {
            continue;
        }

        if(($final_time != 0) && ($evt_time > $final_time))
        {
            return(NULL);
        }


        /* Getting group information */
        $evt_group = strstr($buffer, "-");
        if($evt_group === FALSE)
        {
            /* Invalid group */
            continue;
        }
        
        
        /* Filtering based on the group */
        if($group_pattern != NULL)
        {
            if(strpos($evt_group, $group_pattern) === FALSE)
            {
                continue;
            }
        }
        else if($group_regex != NULL)
        {
            if(!preg_match($group_regex, $evt_group))
            {
                continue;
            }
        }

        /* Getting log formats */
        if($log_pattern != NULL)
        {
            if(strpos($evt_group, $log_pattern) === FALSE)
            {
                continue;
            }
        }
        else if($log_regex != NULL)
        {
            if(!preg_match($log_regex, $evt_group))
            {
                continue;
            }
        }

        

        /* Getting location */
        $buffer = fgets($fp, 1024);
        $evt_location = substr($buffer, 21);
        if($location_pattern)
        {
            if(strpos($evt_location, $location_pattern) === FALSE)
            {
                if(!$rc_code_hash['location_pattern'])
                    continue;
            }
            else
            {
                if($rc_code_hash['location_pattern'])
                    continue;
            }
        }


        /* Getting rule, level and description */
        $buffer = fgets($fp, 1024);
        $token = strtok($buffer, " ");
        if($token === FALSE)
        {
            continue;
        }
        
        
        /* Rule id */
        $token = strtok(" ");
        $evt_id = $token;
        if(is_numeric($evt_id) === FALSE)
        {
            continue;
        }

        /* Checking rule id */
        if($rule_id != NULL)
        {
            if(!preg_match($rule_id, $evt_id))
            {
                continue;
            }
        }
        
        
        /* Level */
        $token = strtok(" ");
        $token = strtok(" ");
        $evt_level = $token;
        $evt_level = rtrim($evt_level, ")");
        if(is_numeric($evt_level) === FALSE)
        {
            continue;
        }

        /* Checking event level */
        if($evt_level < $min_level)
        {
            continue;
        }

        /* Getting description */
        $token = strtok("'");
        $token = strtok("'");
        $evt_description = $token;


/* Starting OSSEC 2.6, "Src IP:" and "User:" are optional in alerts.log */


        /* srcip */
        $buffer = fgets($fp, 2048);

 if(substr($buffer, 0, 7) === "Src IP:")
{
// run srcip code
    $buffer = rtrim($buffer);
        $evt_srcip = substr($buffer, 8);

       /* Validate that string is an IP address*/
        if(filter_var($evt_srcip, FILTER_VALIDATE_IP))
        {
                /* valid IP */
        }
        else
        {
                $evt_srcip = '(none)';
        }


        if($srcip_pattern != NULL)
        {
            if(strpos($evt_srcip,$srcip_pattern) === FALSE)
            {
                if(!$rc_code_hash['srcip_pattern'])
                    continue;
            }
            else
            {
                if($rc_code_hash['srcip_pattern'])
                    continue;
            }
        }

//read line to buffer
$buffer = fgets($fp, 2048);
}

if(substr($buffer, 0, 5) === "User:")
{
// run user code
$buffer = rtrim($buffer);
        if($buffer != "User: (none)")
        {
            $evt_user = substr($buffer, 6);
            if($evt_user == "SYSTEM")
            {
                $evt_user = NULL;
            }
        }
        if($user_pattern)
        {
            if(($evt_user == NULL) ||
               (strpos($evt_user, $user_pattern) === FALSE))
            {
                if(!$rc_code_hash['user_pattern'])
                    continue;
            }
            else
            {
                if($rc_code_hash['user_pattern'])
                    continue;
            }
        }
//read line to buffer
$buffer = fgets($fp, 2048);
}

// move on to message

        /* message */

	$msg_id = 0;
        $evt_msg[$msg_id] = NULL;
        $pattern_matched = 0;
        while(strlen($buffer) > 3)
        {
            if($buffer == "\n")
            {
                break;
            }

            if(($str_pattern != NULL) && 
               (strpos($buffer, $str_pattern) !== FALSE))
            {
                $pattern_matched = 1;
            }

            $evt_msg[$msg_id] = rtrim($buffer);
            $evt_msg[$msg_id] = preg_replace("/</", "&lt;", $evt_msg[$msg_id]);
            $evt_msg[$msg_id] = preg_replace("/>/", "&gt;", $evt_msg[$msg_id]);
            $buffer = fgets($fp, 2048);
            $msg_id++;
            $evt_msg[$msg_id] = NULL;
        }

        /* Searching by pattern */
        if($str_pattern != NULL && $pattern_matched == 0 && 
           $rc_code_hash['str_pattern'])
        {
            $evt_srcip = NULL;
            $evt_user = NULL;
            continue;
        }
        else if(!$rc_code_hash['str_pattern'] && $pattern_matched == 1)
        {
            $evt_srcip = NULL;
            $evt_user = NULL;
            continue;
        }

        /* If we reach here, we got a full alert */

        $alert = new Ossec_Alert( );
        
        $alert->time = $evt_time;
        $alert->id = $evt_id;
        $alert->level = $evt_level;

        // TODO: Why is this being done here? Can't we just use
        // htmlspecialchars() before emitting this to the browser?
        $evt_user = preg_replace("/</", "&lt;", $evt_user);
        $evt_user = preg_replace("/>/", "&gt;", $evt_user);
        $alert->user = $evt_user;

        $evt_srcip = preg_replace("/</", "&lt;", $evt_srcip);
        $evt_srcip = preg_replace("/>/", "&gt;", $evt_srcip);
        $alert->srcip = $evt_srcip;

        $alert->description = $evt_description;
        $alert->location = $evt_location;
        $alert->msg = $evt_msg;

        return($alert);
    }

    return(NULL);
}

function os_searchalerts($ossec_handle, $search_id,
                         $init_time, $final_time, 
                         $max_count,
                         $min_level,
                         $rule_id,
                         $location_pattern,
                         $str_pattern,
                         $group_pattern,
                         $srcip_pattern,
                         $user_pattern,
                         $log_pattern)
{
    $alert_list = new Ossec_AlertList( );
    
    $file_count = 0;
    $file_list[0] = array();

    $output_count = 1;
    $output_file[0] = array();
    $output_file[1] = array();

    $curr_time = time();


    /* Clearing arguments */
    if($rule_id != NULL)
    {
        $rule_id = "/".$rule_id."/";
    }

    $group_regex = null;
    if(strpos($group_pattern,"|") !== FALSE)
    {
        $group_regex = "/".$group_pattern."/";
        $group_pattern = NULL;
    }

    $log_regex = null;
    if(strpos($log_pattern,"|") !== FALSE)
    {
        $log_regex = "/".$log_pattern."/";
        $log_pattern = NULL;
    }
    
    /* Setting rc code */
    if(($user_pattern != NULL) && ($user_pattern[0] == '!'))
    {
        $user_pattern = substr($user_pattern, 1);
        $rc_code_hash['user_pattern'] = TRUE;
    }
    else
    {
        $rc_code_hash['user_pattern'] = FALSE;
    }

    /* str */
    if(($str_pattern != NULL) && ($str_pattern[0] == '!'))
    {
        $str_pattern = substr($str_pattern, 1);
        $rc_code_hash['str_pattern'] = FALSE;
    }
    else
    {
        $rc_code_hash['str_pattern'] = TRUE;
    }

    /* srcip */
    if(($srcip_pattern != NULL) && ($srcip_pattern[0] == '!'))
    {
        $srcip_pattern = substr($srcip_pattern, 1);
        $rc_code_hash['srcip_pattern'] = TRUE;
    }
    else
    {
        $rc_code_hash['srcip_pattern'] = FALSE;
    }
    
    /* location */
    if(($location_pattern != NULL) && ($location_pattern[0] == '!'))
    {
        $location_pattern = substr($location_pattern, 1);
        $rc_code_hash['location_pattern'] = TRUE;
    }
    else
    {
        $rc_code_hash['location_pattern'] = FALSE;
    }
    

    /* Cleaning old entries */
    os_cleanstored(NULL);


    /* Getting first file */
    $init_loop = $init_time;
    while($init_loop < $final_time + 86400)
    {
        $l_year_month = date('Y/M',$init_loop);
        $l_day = date('d',$init_loop);
        
        $file_list[$file_count] = "logs/alerts/".
                                  $l_year_month."/ossec-alerts-".$l_day.".log";

        /* Adding one day */
        $init_loop+=86400;
        $file_count++;
    }
    
    
    /* Getting each file */
    foreach($file_list as $file)
    {

        // If the file does not exist, it must be gzipped so switch to a
        // compressed stream for reading and try again. If that also fails,
        // abort this log file and continue on to the next one.

        $log_file = $ossec_handle['dir'].'/'.$file;
        $fp = @fopen($log_file,'rb');
        if($fp === false) {
            $fp = @fopen("compress.zlib://$log_file.gz", 'rb');
            if($fp === false) { continue; }
        }

        /* Reading all the entries */
        while(1)
        {
            /* Dont get more than max count alerts per page */
            if($alert_list->size( ) >= $max_count)
            {
                $output_file[$output_count] = "./tmp/output-tmp.".
                                            $output_count."-".$alert_list->size( )."-".
                                            $search_id.".php";
                
                __os_createresults($output_file[$output_count], $alert_list); 

                $output_file[0][$output_count] = $alert_list->size( ) -1;
                $alert_list = new Ossec_AlertList( );
                $output_count++;
                $output_file[$output_count] = NULL;
            }
            
            $alert = __os_parsealert($fp, $curr_time, $init_time, 
                                     $final_time, $min_level,
                                     $rule_id, $location_pattern,
                                     $str_pattern, $group_pattern,
                                     $group_regex,
                                     $srcip_pattern, $user_pattern,
                                     $log_pattern, $log_regex,
                                     $rc_code_hash);
            if($alert == NULL)
            {
                break;
            }

            if(! array_key_exists( 'count', $output_file[0] ) ) {
                $output_file[0]['count'] = 0;
            }

            $output_file[0]['count']++;

            /* Adding alert */
            $alert_list->addAlert( $alert );

        }

        /* Closing file */
        fclose($fp);

    }


    /* Creating last entry */
    $output_file[$output_count] = "./tmp/output-tmp.".
                                  $output_count."-".$alert_list->size( )."-".
                                  $search_id.".php";
    
    $output_file[0][$output_count] = $alert_list->size( ) -1;
    $output_file[$output_count +1] = NULL;

     __os_createresults($output_file[$output_count], $alert_list);                                  

    $output_file[0]['pg'] = $output_count;
    return($output_file);
}

function os_cleanstored($search_id = null)
{
    if($search_id != NULL)
    {
        foreach (glob("./tmp/output-tmp.*-*-".$search_id.".php") as $filename)
        {
            unlink($filename);
        }
    }
    else
    {
        foreach (glob("./tmp/*.php") as $filename)
        {
            if(filemtime($filename) < (time() - 1800))
            {
                unlink($filename);
            }
        }
    }
}

// TODO: $ossec_handle is not used here, remove it.
function os_getstoredalerts($ossec_handle, $search_id)
{
    $output_file[0] = NULL;
    $output_file[1] = NULL;
    $output_count = 1;


    /* Cleaning old entries */
    os_cleanstored(NULL);
    
    
    $filepattern = "/^\.\/tmp\/output-tmp\.(\d{1,3})-(\d{1,6})-[a-z0-9]+\.php$/";
    
    foreach (glob("./tmp/output-tmp.*-*-".$search_id.".php") as $filename) 
    {
        if(preg_match($filepattern, $filename, $regs))
        {
            $page_n = $regs[1];
            $alert_count = $regs[2] -1;
        }
        else
        {
            continue;
        }

        if($page_n >= 1 && $page_n < 512)
        {
            $output_file[$page_n] = $filename;
            $output_file[0][$page_n] = $alert_count;
        
            $output_file[$page_n +1] = NULL;
            $output_file[0]['count'] += $alert_count;
            
            $output_count++;
        }
    }

    $output_file[0]['pg'] = $output_count -1;

    return($output_file);
}

function os_getalerts($ossec_handle, $init_time, $final_time, $max_count)
{
    $file = NULL;
    $alert_list = new Ossec_AlertList();
    $curr_time = time(); 

    /* Checking if agent_dir is set */
    if(!isset($ossec_handle['dir']) || ($ossec_handle['dir'] == NULL))
    {
        $ossec_handle['error'] = "Unable to open ossec dir: " . $ossec_handle['dir'];
        return NULL;
    }

    /* Getting log dir */
    $log_file = $ossec_handle['dir'] . '/logs/alerts/alerts.log';

    /* Opening alert file */
    $fp = fopen($log_file, 'r');
    if($fp === false)
    {
        $ossec_handle['error'] = "Unable to open log file: " . $log_file;
        return NULL;
    }

    /* If times are set to zero, we monitor the last *count files. */
    if(($init_time == 0) && ($final_time == 0))
    {
        clearstatcache();
        os_cleanstored();

        /* Getting file size */
        $f_size = filesize($log_file);

        /* Average size of every event: 300-350 */
        $f_point = $max_count * 325;

        /* If file size is large than the counter fseek to the
         * average place in the file.
         */
        if($f_size > $f_point)
        {
            $seek_place = $f_size - $f_point;
            fseek($fp, $seek_place, SEEK_SET); // 修改此处将 SEEK_SET 改为 SEEK_SET 常量
        }
    }

    /* Getting alerts */
    while(1) {
        $alert = __os_parsealert(
            $fp, $curr_time, $init_time, $final_time, 0, NULL, NULL,
            NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
        );

        if($alert == NULL) {
            break;
        }

        $alert_list->addAlert($alert);
    }

    fclose($fp);
    return $alert_list;
}

?>
