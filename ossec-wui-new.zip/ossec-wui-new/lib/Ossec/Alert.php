<?php
/* @(#) $Id: Alert.php,v 1.4 2008/03/03 15:12:18 dcid Exp $ */

/**
 * Ossec Framework
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 *
 * @category   Ossec
 * @package    Ossec
 * @version    $Id: Alert.php,v 1.4 2008/03/03 15:12:18 dcid Exp $
 * @author     Chris Abernethy
 * @copyright  Copyright (c) 2007-2008, Daniel B. Cid <dcid@ossec.net>, All rights reserved.
 * @license    http://www.gnu.org/licenses/gpl-3.0.txt GNU Public License
 */

/**
 * 
 * 
 * @category   Ossec
 * @package    Ossec
 * @copyright  Copyright (c) 2007-2008, Daniel B. Cid, All rights reserved.
 */
class Ossec_Alert {
    public $time;
    public $id;
    public $level;
    public $user;
    public $srcip;
    public $description;
    public $location;
    public $msg;

    public function toHtml() {
        $date = date('Y M d H:i:s', $this->time);
        $idLink = "<a href=\"http://www.ossec.net/doc/search.html?q=rule-id-{$this->id}\">{$this->id}</a>";
        $message = implode('<br/>', $this->msg);

        $htmlOutput = <<<HTML
        <div class="alert">
            <span class="alert-date">$date</span>
            <div class="alert-level">Level: {$this->level} - <span class="alert-description">{$this->description}</span></div>
            <div class="alert-indent">Rule Id: $idLink</div>
            <div class="alert-indent">Location: {$this->location}</div>
            <div class="alert-indent">Src IP: {$this->srcip}</div>
            <div class="alert-indent">User: {$this->user}</div>
            <div class="msg">$message</div>
        </div>
HTML;

        return $htmlOutput;
    }
}
?>